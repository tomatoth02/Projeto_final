# 🎮 Vortex — Sistema de Banco de Dados (Loja de Jogos)

Projeto final da disciplina de **Banco de Dados** — Curso Técnico em Informática Integrado ao Ensino Médio (IFPR — Campus Paranavaí, 2026).

## 📌 Sobre o Projeto
A **Vortex** é uma loja de videogames e acessórios (controles, headsets, consoles) que enfrentava dificuldades para organizar seus cadastros, controlar o estoque e registrar vendas de forma ágil. Este repositório contém a modelagem conceitual/lógica, a documentação completa e os scripts SQL desenvolvidos em **PostgreSQL**.

## 🗂️ Estrutura do Repositório
- `docs/01_documentacao_projeto.md`: Introdução, Requisitos Funcionais (RF), Regras de Negócio (RN), Dicionário de Entidades/Relacionamentos e Dicionário de Dados.
- `sql/01_create_tables.sql`: Script DDL com a criação das tabelas, chaves primárias, estrangeiras e constraints (`CHECK`, `UNIQUE`, `NOT NULL`, `DEFAULT`).
- `sql/02_insert_dados.sql`: Script DML com dados fictícios coerentes para popular o banco e validar os relacionamentos.
- `sql/03_consultas.sql`: Consultas SQL gerenciais respondendo a perguntas do negócio (`JOIN`, `GROUP BY`, `HAVING`, `ORDER BY`, `LIMIT`, `DISTINCT`, funções de agregação e subconsultas).
- `sql/04_testes_integridade.sql`: Testes de operações inválidas para validar as regras de negócio no PostgreSQL.
- `sql/ProjetoBD_Vortex_Completo.sql`: Script unificado pronto para execução e entrega conforme o template da disciplina.

## 🛠️ Tecnologias Utilizadas
- **SGBD:** PostgreSQL
- **Modelagem:** DER / Dicionário de Dados

## 👥 Integrantes
- [Nome do Integrante 1]
- [Nome do Integrante 2]
- [Nome do Integrante 3]

**Professora:** Késsia Marchi
