-- ============================================================================
-- PROJETO FINAL DE BANCO DE DADOS - LOJA DE JOGOS VORTEX
-- Arquivo: 03_consultas.sql
-- Descrição: Consultas gerenciais contemplando todos os recursos exigidos
-- ============================================================================

-- Consulta 1: Quais são os 3 produtos mais caros da loja nas categorias de Jogos ou Controles?
-- Recursos: INNER JOIN, WHERE (operadores lógicos/relacionais), ORDER BY, LIMIT
SELECT
    p.nome AS produto,
    c.nome AS categoria,
    p.plataforma,
    p.preco
FROM produto p
INNER JOIN categoria c ON p.id_categoria = c.id_categoria
WHERE (c.nome = 'Jogos' OR c.nome = 'Controles')
  AND p.estoque > 0
ORDER BY p.preco DESC
LIMIT 3;

-- Consulta 2: Quais plataformas distintas possuem produtos cadastrados na loja?
-- Recursos: DISTINCT, ORDER BY
SELECT DISTINCT
    plataforma
FROM produto
ORDER BY plataforma ASC;

-- Consulta 3: Qual o faturamento total e a quantidade de vendas por forma de pagamento?
-- Recursos: COUNT, SUM, AVG, GROUP BY, ORDER BY
SELECT
    forma_pagamento,
    COUNT(id_venda) AS total_vendas,
    SUM(valor_total) AS faturamento_total,
    ROUND(AVG(valor_total), 2) AS ticket_medio
FROM venda
GROUP BY forma_pagamento
ORDER BY faturamento_total DESC;

-- Consulta 4: Quais clientes já gastaram mais de R$ 600,00 na loja Vortex (Clientes VIP)?
-- Recursos: INNER JOIN, SUM, COUNT, GROUP BY, HAVING, ORDER BY
SELECT
    c.nome AS cliente,
    c.email,
    COUNT(v.id_venda) AS qtd_compras,
    SUM(v.valor_total) AS total_gasto
FROM cliente c
INNER JOIN venda v ON c.id_cliente = v.id_cliente
GROUP BY c.id_cliente, c.nome, c.email
HAVING SUM(v.valor_total) > 600.00
ORDER BY total_gasto DESC;

-- Consulta 5: Quais produtos têm o preço acima da média geral de preços da loja?
-- Recursos: Subconsulta com AVG, WHERE, ORDER BY
SELECT
    nome AS produto,
    plataforma,
    preco
FROM produto
WHERE preco > (
    SELECT AVG(preco) FROM produto
)
ORDER BY preco DESC;

-- Consulta 6: Qual o ranking de quantidade total vendida por produto?
-- Recursos: INNER JOIN múltiplo, SUM, GROUP BY, ORDER BY
SELECT
    p.nome AS produto,
    c.nome AS categoria,
    SUM(iv.quantidade) AS unidades_vendidas,
    SUM(iv.quantidade * iv.preco_unitario) AS receita_gerada
FROM item_venda iv
INNER JOIN produto p ON iv.id_produto = p.id_produto
INNER JOIN categoria c ON p.id_categoria = c.id_categoria
GROUP BY p.id_produto, p.nome, c.nome
ORDER BY unidades_vendidas DESC, receita_gerada DESC;
