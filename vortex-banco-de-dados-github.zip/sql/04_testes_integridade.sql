-- ============================================================================
-- PROJETO FINAL DE BANCO DE DADOS - LOJA DE JOGOS VORTEX
-- Arquivo: 04_testes_integridade.sql
-- Descrição: Testes das constraints (execute individualmente para observar os erros)
-- ============================================================================

-- TESTE 1: Violação de UNIQUE (CPF já cadastrado)
-- Resultado esperado: ERRO - duplicate key value violates unique constraint "cliente_cpf_key"
INSERT INTO cliente (nome, cpf, email)
VALUES ('Cliente Duplicado', '12345678901', 'novo@email.com');

-- TESTE 2: Violação de CHECK (Preço negativo ou zero)
-- Resultado esperado: ERRO - new row for relation "produto" violates check constraint "produto_preco_check"
INSERT INTO produto (nome, plataforma, preco, estoque, id_categoria)
VALUES ('Jogo Teste Inválido', 'PC', -50.00, 5, 1);

-- TESTE 3: Violação de CHECK (Estoque negativo)
-- Resultado esperado: ERRO - new row for relation "produto" violates check constraint "produto_estoque_check"
UPDATE produto SET estoque = -1 WHERE id_produto = 1;

-- TESTE 4: Violação de CHECK (Forma de pagamento não permitida)
-- Resultado esperado: ERRO - new row for relation "venda" violates check constraint "venda_forma_pagamento_check"
INSERT INTO venda (forma_pagamento, valor_total, id_cliente)
VALUES ('Boleto', 299.90, 1);

-- TESTE 5: Violação de FOREIGN KEY (Venda para cliente inexistente)
-- Resultado esperado: ERRO - insert or update on table "venda" violates foreign key constraint "fk_venda_cliente"
INSERT INTO venda (forma_pagamento, valor_total, id_cliente)
VALUES ('Pix', 100.00, 999);
