-- ============================================================================
-- PROJETO FINAL DE BANCO DE DADOS - LOJA DE JOGOS VORTEX
-- Arquivo: 01_create_tables.sql
-- SGBD: PostgreSQL
-- ============================================================================

DROP TABLE IF EXISTS item_venda CASCADE;
DROP TABLE IF EXISTS venda CASCADE;
DROP TABLE IF EXISTS produto CASCADE;
DROP TABLE IF EXISTS categoria CASCADE;
DROP TABLE IF EXISTS cliente CASCADE;

-- Tabela: cliente
CREATE TABLE cliente (
    id_cliente SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf CHAR(11) NOT NULL UNIQUE,
    email VARCHAR(120) NOT NULL UNIQUE,
    telefone VARCHAR(15),
    data_cadastro DATE NOT NULL DEFAULT CURRENT_DATE
);

-- Tabela: categoria
CREATE TABLE categoria (
    id_categoria SERIAL PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE
);

-- Tabela: produto
CREATE TABLE produto (
    id_produto SERIAL PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    plataforma VARCHAR(40) NOT NULL,
    preco NUMERIC(10, 2) NOT NULL CHECK (preco > 0),
    estoque INT NOT NULL DEFAULT 0 CHECK (estoque >= 0),
    id_categoria INT NOT NULL,
    CONSTRAINT fk_produto_categoria FOREIGN KEY (id_categoria)
        REFERENCES categoria (id_categoria)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

-- Tabela: venda
CREATE TABLE venda (
    id_venda SERIAL PRIMARY KEY,
    data_venda TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    forma_pagamento VARCHAR(30) NOT NULL CHECK (
        forma_pagamento IN ('Pix', 'Cartão de Crédito', 'Cartão de Débito', 'Dinheiro')
    ),
    valor_total NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (valor_total >= 0),
    id_cliente INT NOT NULL,
    CONSTRAINT fk_venda_cliente FOREIGN KEY (id_cliente)
        REFERENCES cliente (id_cliente)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

-- Tabela: item_venda (Resolve relacionamento N:N entre venda e produto)
CREATE TABLE item_venda (
    id_venda INT NOT NULL,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL CHECK (quantidade > 0),
    preco_unitario NUMERIC(10, 2) NOT NULL CHECK (preco_unitario > 0),
    PRIMARY KEY (id_venda, id_produto),
    CONSTRAINT fk_item_venda FOREIGN KEY (id_venda)
        REFERENCES venda (id_venda)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_item_produto FOREIGN KEY (id_produto)
        REFERENCES produto (id_produto)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);


-- ============================================================================
-- PROJETO FINAL DE BANCO DE DADOS - LOJA DE JOGOS VORTEX
-- Arquivo: 02_insert_dados.sql
-- Descrição: Inserção de dados iniciais para testes e consultas
-- ============================================================================

-- 1. Categorias
INSERT INTO categoria (nome) VALUES
('Jogos'),
('Controles'),
('Headsets'),
('Consoles');

-- 2. Clientes
INSERT INTO cliente (nome, cpf, email, telefone, data_cadastro) VALUES
('Lucas Almeida', '12345678901', 'lucas.almeida@email.com', '(44) 99911-2233', '2026-08-10'),
('Mariana Costa', '23456789012', 'mariana.costa@email.com', '(44) 99822-3344', '2026-08-15'),
('Pedro Henrique Silva', '34567890123', 'pedro.silva@email.com', '(44) 99733-4455', '2026-09-02'),
('Ana Beatriz Souza', '45678901234', 'ana.souza@email.com', '(44) 99644-5566', '2026-09-20'),
('Rafael Oliveira', '56789012345', 'rafael.oliveira@email.com', NULL, '2026-10-05');

-- 3. Produtos
INSERT INTO produto (nome, plataforma, preco, estoque, id_categoria) VALUES
('God of War Ragnarök', 'PS5', 299.90, 15, 1),
('Elden Ring', 'Multiplataforma', 249.90, 20, 1),
('The Legend of Zelda: Tears of the Kingdom', 'Nintendo Switch', 349.90, 8, 1),
('Controle DualSense Branco', 'PS5', 449.90, 12, 2),
('Controle Xbox Wireless Carbon Black', 'Xbox / PC', 419.90, 10, 2),
('Headset Gamer HyperX Cloud II', 'Multiplataforma', 499.90, 7, 3),
('Headset Pulse 3D Wireless', 'PS5', 549.90, 5, 3),
('Console PlayStation 5 Slim', 'PS5', 3799.90, 4, 4);

-- 4. Vendas
INSERT INTO venda (data_venda, forma_pagamento, valor_total, id_cliente) VALUES
('2026-10-10 14:30:00', 'Pix', 749.80, 1),
('2026-10-12 16:15:00', 'Cartão de Crédito', 4249.80, 2),
('2026-10-18 10:45:00', 'Cartão de Débito', 499.90, 3),
('2026-11-01 18:20:00', 'Pix', 599.80, 1),
('2026-11-05 11:10:00', 'Dinheiro', 419.90, 4);

-- 5. Itens das Vendas
INSERT INTO item_venda (id_venda, id_produto, quantidade, preco_unitario) VALUES
-- Venda 1 (Lucas): God of War (299.90) + Controle DualSense (449.90)
(1, 1, 1, 299.90),
(1, 4, 1, 449.90),
-- Venda 2 (Mariana): PS5 Slim (3799.90) + Controle DualSense (449.90)
(2, 8, 1, 3799.90),
(2, 4, 1, 449.90),
-- Venda 3 (Pedro): Headset HyperX Cloud II (499.90)
(3, 6, 1, 499.90),
-- Venda 4 (Lucas): 1x Elden Ring (249.90) + 1x Zelda (349.90)
(4, 2, 1, 249.90),
(4, 3, 1, 349.90),
-- Venda 5 (Ana Beatriz): Controle Xbox (419.90)
(5, 5, 1, 419.90);


-- ============================================================================
-- PROJETO FINAL DE BANCO DE DADOS - LOJA DE JOGOS VORTEX
-- Arquivo: 03_consultas.sql
-- Descrição: Consultas gerenciais contemplando todos os recursos exigidos
-- ============================================================================

-- Consulta 1: Quais são os 3 produtos mais caros da loja nas categorias de Jogos ou Controles?
-- Recursos: INNER JOIN, WHERE (operadores lógicos/relacionais), ORDER BY, LIMIT
SELECT
    p.nome AS produto,
    c.nome AS categoria,
    p.plataforma,
    p.preco
FROM produto p
INNER JOIN categoria c ON p.id_categoria = c.id_categoria
WHERE (c.nome = 'Jogos' OR c.nome = 'Controles')
  AND p.estoque > 0
ORDER BY p.preco DESC
LIMIT 3;

-- Consulta 2: Quais plataformas distintas possuem produtos cadastrados na loja?
-- Recursos: DISTINCT, ORDER BY
SELECT DISTINCT
    plataforma
FROM produto
ORDER BY plataforma ASC;

-- Consulta 3: Qual o faturamento total e a quantidade de vendas por forma de pagamento?
-- Recursos: COUNT, SUM, AVG, GROUP BY, ORDER BY
SELECT
    forma_pagamento,
    COUNT(id_venda) AS total_vendas,
    SUM(valor_total) AS faturamento_total,
    ROUND(AVG(valor_total), 2) AS ticket_medio
FROM venda
GROUP BY forma_pagamento
ORDER BY faturamento_total DESC;

-- Consulta 4: Quais clientes já gastaram mais de R$ 600,00 na loja Vortex (Clientes VIP)?
-- Recursos: INNER JOIN, SUM, COUNT, GROUP BY, HAVING, ORDER BY
SELECT
    c.nome AS cliente,
    c.email,
    COUNT(v.id_venda) AS qtd_compras,
    SUM(v.valor_total) AS total_gasto
FROM cliente c
INNER JOIN venda v ON c.id_cliente = v.id_cliente
GROUP BY c.id_cliente, c.nome, c.email
HAVING SUM(v.valor_total) > 600.00
ORDER BY total_gasto DESC;

-- Consulta 5: Quais produtos têm o preço acima da média geral de preços da loja?
-- Recursos: Subconsulta com AVG, WHERE, ORDER BY
SELECT
    nome AS produto,
    plataforma,
    preco
FROM produto
WHERE preco > (
    SELECT AVG(preco) FROM produto
)
ORDER BY preco DESC;

-- Consulta 6: Qual o ranking de quantidade total vendida por produto?
-- Recursos: INNER JOIN múltiplo, SUM, GROUP BY, ORDER BY
SELECT
    p.nome AS produto,
    c.nome AS categoria,
    SUM(iv.quantidade) AS unidades_vendidas,
    SUM(iv.quantidade * iv.preco_unitario) AS receita_gerada
FROM item_venda iv
INNER JOIN produto p ON iv.id_produto = p.id_produto
INNER JOIN categoria c ON p.id_categoria = c.id_categoria
GROUP BY p.id_produto, p.nome, c.nome
ORDER BY unidades_vendidas DESC, receita_gerada DESC;


-- ============================================================================
-- OBSERVAÇÃO: Os testes de integridade (que geram erros propositais) estão
-- comentados abaixo para não interromper a execução completa do script.
-- ============================================================================
/*
-- ============================================================================
-- PROJETO FINAL DE BANCO DE DADOS - LOJA DE JOGOS VORTEX
-- Arquivo: 04_testes_integridade.sql
-- Descrição: Testes das constraints (execute individualmente para observar os erros)
-- ============================================================================

-- TESTE 1: Violação de UNIQUE (CPF já cadastrado)
-- Resultado esperado: ERRO - duplicate key value violates unique constraint "cliente_cpf_key"
INSERT INTO cliente (nome, cpf, email)
VALUES ('Cliente Duplicado', '12345678901', 'novo@email.com');

-- TESTE 2: Violação de CHECK (Preço negativo ou zero)
-- Resultado esperado: ERRO - new row for relation "produto" violates check constraint "produto_preco_check"
INSERT INTO produto (nome, plataforma, preco, estoque, id_categoria)
VALUES ('Jogo Teste Inválido', 'PC', -50.00, 5, 1);

-- TESTE 3: Violação de CHECK (Estoque negativo)
-- Resultado esperado: ERRO - new row for relation "produto" violates check constraint "produto_estoque_check"
UPDATE produto SET estoque = -1 WHERE id_produto = 1;

-- TESTE 4: Violação de CHECK (Forma de pagamento não permitida)
-- Resultado esperado: ERRO - new row for relation "venda" violates check constraint "venda_forma_pagamento_check"
INSERT INTO venda (forma_pagamento, valor_total, id_cliente)
VALUES ('Boleto', 299.90, 1);

-- TESTE 5: Violação de FOREIGN KEY (Venda para cliente inexistente)
-- Resultado esperado: ERRO - insert or update on table "venda" violates foreign key constraint "fk_venda_cliente"
INSERT INTO venda (forma_pagamento, valor_total, id_cliente)
VALUES ('Pix', 100.00, 999);

*/