-- ============================================================================
-- PROJETO FINAL DE BANCO DE DADOS - LOJA DE JOGOS VORTEX
-- Arquivo: 02_insert_dados.sql
-- Descrição: Inserção de dados iniciais para testes e consultas
-- ============================================================================

-- 1. Categorias
INSERT INTO categoria (nome) VALUES
('Jogos'),
('Controles'),
('Headsets'),
('Consoles');

-- 2. Clientes
INSERT INTO cliente (nome, cpf, email, telefone, data_cadastro) VALUES
('Lucas Almeida', '12345678901', 'lucas.almeida@email.com', '(44) 99911-2233', '2026-08-10'),
('Mariana Costa', '23456789012', 'mariana.costa@email.com', '(44) 99822-3344', '2026-08-15'),
('Pedro Henrique Silva', '34567890123', 'pedro.silva@email.com', '(44) 99733-4455', '2026-09-02'),
('Ana Beatriz Souza', '45678901234', 'ana.souza@email.com', '(44) 99644-5566', '2026-09-20'),
('Rafael Oliveira', '56789012345', 'rafael.oliveira@email.com', NULL, '2026-10-05');

-- 3. Produtos
INSERT INTO produto (nome, plataforma, preco, estoque, id_categoria) VALUES
('God of War Ragnarök', 'PS5', 299.90, 15, 1),
('Elden Ring', 'Multiplataforma', 249.90, 20, 1),
('The Legend of Zelda: Tears of the Kingdom', 'Nintendo Switch', 349.90, 8, 1),
('Controle DualSense Branco', 'PS5', 449.90, 12, 2),
('Controle Xbox Wireless Carbon Black', 'Xbox / PC', 419.90, 10, 2),
('Headset Gamer HyperX Cloud II', 'Multiplataforma', 499.90, 7, 3),
('Headset Pulse 3D Wireless', 'PS5', 549.90, 5, 3),
('Console PlayStation 5 Slim', 'PS5', 3799.90, 4, 4);

-- 4. Vendas
INSERT INTO venda (data_venda, forma_pagamento, valor_total, id_cliente) VALUES
('2026-10-10 14:30:00', 'Pix', 749.80, 1),
('2026-10-12 16:15:00', 'Cartão de Crédito', 4249.80, 2),
('2026-10-18 10:45:00', 'Cartão de Débito', 499.90, 3),
('2026-11-01 18:20:00', 'Pix', 599.80, 1),
('2026-11-05 11:10:00', 'Dinheiro', 419.90, 4);

-- 5. Itens das Vendas
INSERT INTO item_venda (id_venda, id_produto, quantidade, preco_unitario) VALUES
-- Venda 1 (Lucas): God of War (299.90) + Controle DualSense (449.90)
(1, 1, 1, 299.90),
(1, 4, 1, 449.90),
-- Venda 2 (Mariana): PS5 Slim (3799.90) + Controle DualSense (449.90)
(2, 8, 1, 3799.90),
(2, 4, 1, 449.90),
-- Venda 3 (Pedro): Headset HyperX Cloud II (499.90)
(3, 6, 1, 499.90),
-- Venda 4 (Lucas): 1x Elden Ring (249.90) + 1x Zelda (349.90)
(4, 2, 1, 249.90),
(4, 3, 1, 349.90),
-- Venda 5 (Ana Beatriz): Controle Xbox (419.90)
(5, 5, 1, 419.90);
