# Documentação do Projeto — Banco de Dados Vortex

## 1. Introdução
### 1.1 Contexto e domínio da aplicação
A loja de jogos **Vortex** atua no comércio varejista de videogames e acessórios gamers, como controles, headsets e periféricos. Com o crescimento do catálogo de produtos e da carteira de clientes, o controle manual tornou-se lento e sujeito a falhas no acompanhamento de estoque e histórico de compras.

### 1.2 Objetivo do projeto
Desenvolver um banco de dados relacional em **PostgreSQL** capaz de armazenar, organizar e relacionar informações de clientes, categorias, produtos, vendas e itens vendidos, garantindo integridade dos dados e agilidade nas consultas gerenciais.

### 1.3 Escopo
O projeto contempla a modelagem entidade-relacionamento, o dicionário de dados, a implementação física das tabelas com restrições de integridade, a carga inicial de dados para testes e um conjunto de consultas SQL voltadas à tomada de decisão da loja. Não fazem parte do escopo o desenvolvimento de interface gráfica ou aplicação web/desktop.

---

## 2. Levantamento de Requisitos

### 2.1 Requisitos Funcionais
| ID | Requisito Funcional |
| :--- | :--- |
| **RF01** | O sistema deve permitir o cadastro de clientes contendo nome completo, CPF, e-mail, telefone e data de cadastro. |
| **RF02** | O sistema deve permitir o cadastro de categorias de produtos (ex.: Jogos, Controles, Headsets, Consoles). |
| **RF03** | O sistema deve permitir o cadastro de produtos com nome, plataforma, preço unitário, quantidade em estoque e categoria associada. |
| **RF04** | O sistema deve permitir o registro de vendas vinculadas a um cliente, contendo data/hora, forma de pagamento e valor total. |
| **RF05** | O sistema deve permitir o registro dos itens pertencentes a cada venda, especificando o produto, a quantidade vendida e o preço unitário praticado no momento da venda. |
| **RF06** | O banco de dados deve permitir consultas para listar histórico de compras por cliente, produtos mais vendidos, faturamento por categoria e controle de estoque. |

### 2.2 Regras de Negócio
| ID | Regra de Negócio |
| :--- | :--- |
| **RN01** | Cada cliente deve possuir um CPF e um e-mail únicos no sistema, não sendo permitido cadastro duplicado (`UNIQUE`). |
| **RN02** | Não é permitido cadastrar produtos com preço igual ou inferior a zero (`CHECK (preco > 0)`). |
| **RN03** | A quantidade em estoque de um produto nunca pode ser negativa (`CHECK (estoque >= 0)`). |
| **RN04** | Todo item registrado em uma venda deve possuir quantidade maior que zero (`CHECK (quantidade > 0)`). |
| **RN05** | As formas de pagamento aceitas pela loja são restritas a: `'Pix'`, `'Cartão de Crédito'`, `'Cartão de Débito'` e `'Dinheiro'`. |

---

## 3. Projeto de Dados

### 3.1 Entidades
- **cliente**: Armazena os dados cadastrais dos consumidores da loja Vortex.
- **categoria**: Classifica os produtos comercializados pela loja (ex.: Jogos, Acessórios, Consoles).
- **produto**: Representa os itens disponíveis para venda na loja, com preço, plataforma e saldo em estoque.
- **venda**: Registra o cabeçalho da transação comercial realizada por um cliente.
- **item_venda**: Entidade associativa que detalha quais produtos e em quais quantidades compõem cada venda.

### 3.2 Relacionamentos
- **possui (categoria — produto | 1:N)**: Uma categoria pode classificar vários produtos, mas cada produto pertence a apenas uma categoria.
- **realiza (cliente — venda | 1:N)**: Um cliente pode realizar várias vendas ao longo do tempo, e cada venda pertence a um único cliente.
- **contém (venda — item_venda — produto | N:N resolvido)**: Uma venda pode conter vários produtos, e um mesmo produto pode estar presente em várias vendas diferentes.
